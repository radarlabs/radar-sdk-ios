//
//  RadarGeofenceGeometry.h
//  RadarSDK
//
//  Created by Russell Cullen on 9/17/18.
//  Copyright © 2018 Radar. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 Represents the geometry of a geofence.
 */
@interface RadarGeofenceGeometry : NSObject

@end
